

import React, { useState } from 'react';
import ImageUpload from './ImageUpload';
import ObjectDetector from './ObjectDetector';
import CanvasEditor from './CanvasEditor';

export default function Dashboard() {
  const [uploadedPath, setUploadedPath] = useState('');
  const [detections, setDetections] = useState([]);

  const handleUpload = (path) => {
    setUploadedPath(`http://localhost:5000${path}`);
    setDetections([]);
  };

  return (
    <div>
      <h2>Dashboard: Image Detection & Editing</h2>
      <ImageUpload onUpload={handleUpload} />
      {uploadedPath && (
        <>
          <ObjectDetector imageUrl={uploadedPath} onDetect={setDetections} />
          <CanvasEditor imageUrl={uploadedPath} boxes={detections} />
        </>
      )}
    </div>
  );
}
