import React from 'react';
import { Stage, Layer, Rect, Text } from 'react-konva';

export default function CanvasEditor({ imageUrl, boxes }) {
  const imageWidth = 400;
  const imageHeight = 400;

  return (
    <Stage width={imageWidth} height={imageHeight}>
      <Layer>
        {boxes.map((box, i) => (
          <React.Fragment key={i}>
            <Rect
              x={box.bbox[0]}
              y={box.bbox[1]}
              width={box.bbox[2]}
              height={box.bbox[3]}
              stroke="red"
              strokeWidth={2}
              draggable
            />
            <Text
              text={box.class}
              x={box.bbox[0]}
              y={box.bbox[1] - 20}
              fill="red"
              fontSize={16}
            />
          </React.Fragment>
        ))}
      </Layer>
    </Stage>
  );
}
