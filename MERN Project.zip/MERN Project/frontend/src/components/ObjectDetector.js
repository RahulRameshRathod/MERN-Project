import React, { useRef, useEffect, useState } from 'react';
import * as cocoSsd from '@tensorflow-models/coco-ssd';
import '@tensorflow/tfjs';

export default function ObjectDetector({ imageUrl, onDetect }) {
  const imageRef = useRef();
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!imageUrl) return;
    const detectObjects = async () => {
      setLoading(true);
      const img = imageRef.current;

      const model = await cocoSsd.load();
      const predictions = await model.detect(img);
      setLoading(false);
      onDetect(predictions);
    };

    detectObjects();
  }, [imageUrl, onDetect]);

  return (
    <div>
      {imageUrl && <img ref={imageRef} src={imageUrl} alt="To Detect" width="400" crossOrigin="anonymous" />}
      {loading && <p>Detecting objects...</p>}
    </div>
  );
}
