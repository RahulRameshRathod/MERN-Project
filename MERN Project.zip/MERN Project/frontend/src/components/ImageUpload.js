import React, { useState } from 'react';
import axios from 'axios';

export default function ImageUpload({ onUpload }) {
    const [image, setImage] = useState(null);
  
    const handleUpload = async () => {
      if (!image) return alert('Please select an image');
  
      const formData = new FormData();
      formData.append('image', image);
  
      try {
        const res = await axios.post('http://localhost:5000/api/upload', formData);
        onUpload(res.data.filePath);  
      } catch (err) {
        alert('Upload failed');
      }
    };
  
    return (
      <div>
        <input type="file" onChange={(e) => setImage(e.target.files[0])} />
        <button onClick={handleUpload}>Upload</button>
      </div>
    );
  }
  